function addOutput(num) {
    var display = document.getElementById("display");
    display.value = display.value + num;
  }
   
  function calculate() {
    var display = document.getElementById("display");
    var result = eval(display.value);
    var displayResult = document.getElementById("display");
    displayResult.value = result;
  }

   
  function reset() {
    var display = document.getElementById("display");
    display.value = "";
    var displayResult = document.getElementById("result");
    displayResult.value = "";
  }
  